import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DYNAMODB_TABLE_NAME = os.environ.get('DYNAMODB_TABLE_NAME')
WEBSOCKET_API_ENDPOINT = os.environ.get('WEBSOCKET_API_ENDPOINT')

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DYNAMODB_TABLE_NAME)

def handler(event, context):
    if not DYNAMODB_TABLE_NAME or not WEBSOCKET_API_ENDPOINT:
        logger.error("FATAL: Environment variables DYNAMODB_TABLE_NAME or WEBSOCKET_API_ENDPOINT not set.")
        return

    # Az 'event' itt közvetlenül az IoT Topic-ról érkező payload
    payload_to_send = json.dumps(event)
    logger.info(f"Broadcasting payload: {payload_to_send}")

    # API Gateway Management kliens inicializálása
    apigw_management_client = boto3.client(
        'apigatewaymanagementapi',
        endpoint_url=WEBSOCKET_API_ENDPOINT
    )

    # Összes aktív kapcsolat lekérdezése a DynamoDB-ből
    try:
        response = table.scan(ProjectionExpression='connectionId')
        connections = response.get('Items', [])
    except Exception as e:
        logger.error(f"Failed to scan DynamoDB table: {e}")
        return

    if not connections:
        logger.info("No active WebSocket connections found. Skipping broadcast.")
        return

    # Üzenet küldése minden csatlakozott kliensnek
    stale_connections = []
    for connection in connections:
        connection_id = connection['connectionId']
        try:
            apigw_management_client.post_to_connection(
                ConnectionId=connection_id,
                Data=payload_to_send
            )
            logger.info(f"Sent to connectionId: {connection_id}")
        except apigw_management_client.exceptions.GoneException:
            logger.warning(f"ConnectionId {connection_id} is stale. Marking for deletion.")
            stale_connections.append(connection_id)
        except Exception as e:
            logger.error(f"Failed to post to connection {connection_id}: {e}")

    # Lezárult kapcsolatok törlése a táblából
    if stale_connections:
        with table.batch_writer() as batch:
            for connection_id in stale_connections:
                batch.delete_item(Key={'connectionId': connection_id})
        logger.info(f"Deleted {len(stale_connections)} stale connections.")

