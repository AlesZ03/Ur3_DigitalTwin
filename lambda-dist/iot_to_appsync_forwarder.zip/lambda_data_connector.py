import os
import json
import logging
import urllib.request
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.session import get_session

# Logger beállítása
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Környezeti változóból olvassuk az AppSync API URL-t
APPSYNC_API_URL = os.environ.get('APPSYNC_API_URL')
if not APPSYNC_API_URL:
    logger.error("FATAL: Missing required environment variable APPSYNC_API_URL.")
    raise ValueError("Missing APPSYNC_API_URL environment variable.")

REGION = APPSYNC_API_URL.split('.')[2]

# GraphQL Mutation
MUTATION = """
mutation PublishShadowUpdate($state: ShadowStateInput!, $version: Int, $timestamp: AWSTimestamp) {
  publishShadowUpdate(state: $state, version: $version, timestamp: $timestamp) {
    version
    state {
      reported {
        joint_positions
        timestamp
      }
    }
  }
}
"""

def sign_and_make_request(query, variables):
    """Aláírja a GraphQL kérést SigV4-gyel és elküldi a beépített urllib használatával."""
    session = get_session()
    credentials = session.get_credentials().get_frozen_credentials()
    
    payload = json.dumps({"query": query, "variables": variables}).encode('utf-8')
    
    request = AWSRequest(
        method="POST",
        url=APPSYNC_API_URL,
        data=payload,
        headers={'Content-Type': 'application/json'}
    )
    
    # Aláírás generálása és hozzáadása a headerekhez
    SigV4Auth(credentials, "appsync", REGION).add_auth(request)
    prepared_request = request.prepare()
    
    # HTTP kérés felépítése a beépített urllib.request segítségével
    req = urllib.request.Request(
        prepared_request.url,
        data=prepared_request.body,
        headers=prepared_request.headers,
        method=prepared_request.method
    )
    
    try:
        with urllib.request.urlopen(req) as response:
            response_body = response.read().decode('utf-8')
            logger.info(f"AppSync response status code: {response.status}")
            logger.info(f"AppSync response: {response_body}")
            return json.loads(response_body)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error(f"HTTP Error calling AppSync: {e.code} - {error_body}")
        raise Exception(f"HTTPError {e.code}: {error_body}")
    except Exception as e:
        logger.error(f"Unexpected error calling AppSync: {str(e)}")
        raise e

def lambda_handler(event, context):
    """A Lambda belépési pontja, amit az IoT Rule hív meg."""
    logger.info(f"Event received from IoT Rule: {json.dumps(event)}")

    variables = {
        "state": event.get('state', {}),
        "version": event.get('version'),
        "timestamp": event.get('timestamp')
    }

    try:
        logger.info(f"Calling AppSync mutation with variables: {json.dumps(variables)}")
        response = sign_and_make_request(MUTATION, variables)
        return {'statusCode': 200, 'body': json.dumps(response)}
    except Exception as e:
        logger.error(f"Error in lambda execution: {str(e)}")
        return {'statusCode': 500, 'body': f"Error calling AppSync: {str(e)}"}